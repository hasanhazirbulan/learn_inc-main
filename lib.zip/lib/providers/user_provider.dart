import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';

class UserProvider with ChangeNotifier {
  UserModel? _user;
  bool _isDataLoaded = false;
  bool _isDayMode = true;

  UserProvider() {
    FirebaseAuth.instance.authStateChanges().listen((user) {
      if (user != null) {
        loadUserData();
      } else {
        _user = null;
        notifyListeners();
      }
    });
  }

  UserModel? get user => _user;
  bool get isDataLoaded => _isDataLoaded;
  bool get isDayMode => _isDayMode;

  void toggleTheme() {
    _isDayMode = !_isDayMode;
    notifyListeners();
  }

  Future<void> loadUserData() async {
    try {
      _isDataLoaded = false;
      notifyListeners();

      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) {
        return;
      }

      final userDoc = await FirebaseFirestore.instance.collection('Users').doc(uid).get();
      if (userDoc.exists) {
        final data = userDoc.data();
        _user = UserModel.fromJson(data!, uid);
      } else {
        _user = null;
      }
    } catch (e) {
      print("Error loading user data: $e");
      _user = null;
    } finally {
      _isDataLoaded = true;
      notifyListeners();
    }
  }

  Future<void> updateUserName(String newName) async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid != null) {
        await FirebaseFirestore.instance.collection('Users').doc(uid).update({'FullName': newName});
        _user = _user!.copyWith(fullName: newName);
        notifyListeners();
      }
    } catch (e) {
      print("Error updating name: $e");
    }
  }

  Future<void> updateUserProfileImage(String newImageUrl) async {
    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid != null) {
        await FirebaseFirestore.instance.collection('Users').doc(uid).update({
          'ProfileImage': newImageUrl,
        });
        _user = _user?.copyWith(profileImage: newImageUrl); // Update local model
        notifyListeners();
      }
    } catch (e) {
      print("Error updating profile image: $e");
    }
  }


  Future<void> logout() async {
    try {
      await FirebaseAuth.instance.signOut();
      _user = null;
      _isDataLoaded = false;
      _isDayMode = true; // Optionally reset theme
      notifyListeners();
    } catch (e) {
      print("Error logging out: $e");
    }
  }
}
