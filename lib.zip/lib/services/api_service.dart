import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String apiKey = 'AIzaSyC5gpQ5AHZDwHoJNOigtVDrRh3qgkh45RU'; // Replace with your actual API key
  final String endpoint =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent';

  /// Chatbot API Call
  Future<String> callChatbot(String userMessage) async {
    try {
      final response = await http.post(
        Uri.parse('$endpoint?key=$apiKey'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "contents": [
            {
              "parts": [
                {"text": userMessage}
              ]
            }
          ]
        }),
      );

      print("Chatbot API Response: ${response.body}"); // Debug the response

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        // Validate response structure
        if (_validateResponse(data)) {
          return data['candidates'][0]['content']['parts'][0]['text'];
        } else {
          throw Exception("Invalid response structure: ${response.body}");
        }
      } else {
        throw Exception(
            'Chatbot API call failed: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print("Error in callChatbot: $e");
      return "An error occurred. Please try again.";
    }
  }

  /// Document Summarization API Call
  Future<String> summarizeDocument(String document) async {
    try {
      final response = await http.post(
        Uri.parse('$endpoint?key=$apiKey'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "contents": [
            {
              "parts": [
                {"text": "Summarize the following document:\n\n$document"}
              ]
            }
          ]
        }),
      );

      print("Summarization API Response: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        // Validate response structure
        if (_validateResponse(data)) {
          return data['candidates'][0]['content']['parts'][0]['text'];
        } else {
          throw Exception("Invalid response structure: ${response.body}");
        }
      } else {
        throw Exception(
            'Summarization API call failed: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print("Error in summarizeDocument: $e");
      return "An error occurred during summarization. Please try again.";
    }
  }

  /// Generate Flashcards API Call
  Future<List<String>> generateFlashcards(String text) async {
    try {
      final response = await http.post(
        Uri.parse('$endpoint?key=$apiKey'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "contents": [
            {
              "parts": [
                {"text": "Generate flashcards based on the following text:\n\n$text"}
              ]
            }
          ]
        }),
      );

      print("Flashcards API Response: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        // Validate response structure
        if (_validateResponse(data)) {
          final result = data['candidates'][0]['content']['parts'][0]['text'];
          return result.split('\n').where((line) => line.trim().isNotEmpty).toList();
        } else {
          throw Exception("Invalid response structure: ${response.body}");
        }
      } else {
        throw Exception(
            'Flashcards API call failed: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print("Error in generateFlashcards: $e");
      return ["An error occurred while generating flashcards. Please try again."];
    }
  }

  /// Extract Key Points API Call
  Future<List<String>> getKeyPoints(String document) async {
    try {
      final response = await http.post(
        Uri.parse('$endpoint?key=$apiKey'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "contents": [
            {
              "parts": [
                {"text": "Extract key points from the following document:\n\n$document"}
              ]
            }
          ]
        }),
      );

      print("Key Points API Response: ${response.body}");

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        // Validate response structure
        if (_validateResponse(data)) {
          final result = data['candidates'][0]['content']['parts'][0]['text'];
          return result.split('\n').where((line) => line.trim().isNotEmpty).toList();
        } else {
          throw Exception("Invalid response structure: ${response.body}");
        }
      } else {
        throw Exception(
            'Key Points API call failed: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print("Error in getKeyPoints: $e");
      return ["An error occurred while extracting key points. Please try again."];
    }
  }

  /// Generate Flashcards from Document
  Future<List<String>> generateFlashcardsFromDocument(String document) async {
    try {
      List<String> keyPoints = await getKeyPoints(document);
      return keyPoints;
    } catch (e) {
      print("Error in generateFlashcardsFromDocument: $e");
      return ["An error occurred while generating flashcards. Please try again."];
    }
  }

  /// Validate API Response Structure
  bool _validateResponse(dynamic data) {
    return data != null &&
        data['candidates'] != null &&
        data['candidates'] is List &&
        data['candidates'].isNotEmpty &&
        data['candidates'][0]['content'] != null &&
        data['candidates'][0]['content']['parts'] != null &&
        data['candidates'][0]['content']['parts'] is List &&
        data['candidates'][0]['content']['parts'].isNotEmpty &&
        data['candidates'][0]['content']['parts'][0]['text'] != null;
  }
}
